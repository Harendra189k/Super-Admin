import React from 'react'
import Sidebar from '../../components/sidebar/Sidebar'
import TopNavBar from '../../components/TopNavBar'
import { useForm } from 'react-hook-form';

const ChangePassword = () => {
  
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  return (
    <>
        <Sidebar />
        <TopNavBar />
        <div>
        <div class="container">
    <h1>Edit Profile</h1>
	<div className="row mt-20">
      
      <div className="col-md-9 personal-info">
       
        
        <form className="form-horizontal mt-4" role="form" onSubmit={handleSubmit((data) => console.log(data))}>
<div className="form-group">
            <label className="profile-label">Old Passw:</label>
            <div className="col-md-8">
              <input className="form-control" type="text" placeholder='Old Password'
              {...register('Old_Password', { required: "Please Enter Your Old Password",
                minLength: {
                  value: 8,
                  message: "Password Must contain 8 charecters"
                }
              })}
              />
              <p className='error-msg'>{errors.Old_Password?.message}</p>
            </div>
            <label className="profile-label-ln ">New Pass:</label>
            <div className="col-md-8">
              <input className="form-control" type="text" placeholder='New Password'
              {...register('New_password', { required: "New Password is required",
                minLength: {
                  value: 2,
                  message: "New Password Must contain 8 charecters"
                }
              })}
              />
              <p className='error-msg'>{errors.New_password?.message}</p>
            </div>
          </div>
          <div className="form-group">
            <label className="profile-label-em ">Confirm</label>
            <div className="col-lg-8">
             <input
  className="form-control"
  type="text"
  placeholder="Confirm Password"
  {...register('confirm_password', {
    required: "confirm password is required",
  })}
/>
<p className="error-msg">{errors.confirm_password?.message}</p>
            </div>
          </div>
         
          <div className="form-group">
            <label className="col-md-3 control-label"></label>
            <div className="col-md-8">
              <input type="submit" className="btn btn-primary" value="Save Changes"/>
              <span></span>
              <input type="reset" className="btn btn-default" value="Cancel"/>
            </div>
          </div>
        </form>
      </div>
  </div>
</div>
        </div>
    </>
    
  )
}

export default ChangePassword

