import React, { useEffect, useState } from 'react'
// import OCountUp from "../../components/OCountUp";
import earning from "../../assets/images/earning.jpg";
import { useTranslation } from "react-i18next";
import Sidebar from '../../components/sidebar/Sidebar';
import { FaUserTie } from "react-icons/fa";
import TopNavBar from '../../components/TopNavBar';
import OCountUp from '../../components/OCountUp';
import { MdOutlineSportsSoccer } from "react-icons/md";
import { FaRunning } from "react-icons/fa";
import { GiBabyfootPlayers } from "react-icons/gi";
import { RiTeamFill } from "react-icons/ri";
import { apiGet } from '../../services/httpServices';
import { pathObj } from '../../services/apiPath';


const Home = () => {

    const { t } = useTranslation();
    const [ dashboardDetails, setDashboardDetails] = useState({})

    const countData = async (data) => {
      try {
        const response = await apiGet(pathObj.GET_COUNT);
    
        if (response.status === 200) {
          setDashboardDetails(response.data);
        } else {
          console.log('Something went wrong');
        }
    
      } catch (error) {
        console.error(error);
      }
    };
    useEffect(() => {
      countData();
    }, []);

  return (
    <>
    <Sidebar />
    <TopNavBar />
    <div className="py-4 px-4 md:px-8 dark:bg-slate-900 home-adj">
      <div className="sale_report grid pt-10 3xl:grid-cols-4 gap-y-10 gap-4 gap-x-10 2xl:grid-cols-4 sm:grid-cols-2 mb-7 ">
        <div className="text-center relative  sm:text-left px-3 md:px-4 xl:px-6 lg:px-5 rounded-lg py-4 md:py-8 border">
          <h3 className="text-center mb-0 text-slate-900 font-bold md:text-3xl sm:text-lg dark:text-white">
            <OCountUp value={dashboardDetails?.coach} />
            <span className="text-base text-neutral-400 font-normal block pt-3 ">{t("VIEW_NO_OF_COACHES")}</span>
          </h3>
          <span className="text-4xl ml-auto sm:mr-0  mt-2 sm:mt-0 absolute right-[-10px] top-[-30px] p-3 border z-10 bg-white">
            <FaUserTie /> 
          </span>
        </div>

        <div className="text-center relative  sm:text-left px-3 md:px-4 xl:px-6 lg:px-5 rounded-lg py-4 md:py-8 border">
          <h3 className="text-center mb-0 text-slate-900 font-bold md:text-3xl sm:text-lg dark:text-white">
            <OCountUp value={dashboardDetails?.athlete} />

            <span className="text-base text-neutral-400 font-normal block pt-3 ">{t("VIEW_NO_OF_ATHLETES")}</span>
          </h3>
          <span className="text-4xl ml-auto sm:mr-0  mt-2 sm:mt-0 absolute right-[-10px] top-[-30px] p-3 border z-10 bg-white">
          <FaRunning />

          </span>
        </div>
        <div className="text-center relative  sm:text-left px-3 md:px-4 xl:px-6 lg:px-5 rounded-lg py-4 md:py-8 border">
          <h3 className="text-center mb-0 text-slate-900 font-bold md:text-3xl sm:text-lg dark:text-white">
          <OCountUp value={dashboardDetails?.totalSports} />
            <span className="text-base text-neutral-400 font-normal block pt-3 ">{t("TOTAL_NUMBER_OF_SPORTS")}</span>
          </h3>
          <span className="text-4xl ml-auto sm:mr-0  mt-2 sm:mt-0 absolute right-[-10px] top-[-30px] p-3 border z-10 bg-white">
            {/* <img src={earning} className="h-8 w-8 bg-black" alt="earningImg" /> */}
            <MdOutlineSportsSoccer />

          </span>
        </div>
        <div className="text-center relative  sm:text-left px-3 md:px-4 xl:px-6 lg:px-5 rounded-lg py-4 md:py-8 border">
          <h3 className="text-center mb-0 text-slate-900 font-bold md:text-3xl sm:text-lg dark:text-white">
          <OCountUp value={dashboardDetails?.addPlayer} />
            <span className="text-base text-neutral-400 font-normal block pt-3 ">{t("TOTAL_NUMBER_OF_TEAMS")}</span>
          </h3>
          <span className="text-4xl ml-auto sm:mr-0  mt-2 sm:mt-0 absolute right-[-10px] top-[-30px] p-3 border z-10 bg-white">
            {/* <img src={earning} className="h-8 w-8 bg-black" alt="earningImg" /> */}
            <RiTeamFill />

          </span>
        </div>

        <div className="text-center relative  sm:text-left px-3 md:px-4 xl:px-6 lg:px-5 rounded-lg py-4 md:py-8 border">
          <h3 className="text-center mb-0 text-slate-900 font-bold md:text-3xl sm:text-lg dark:text-white">
          <OCountUp value={dashboardDetails?.addPlayer} />
            <span className="text-base text-neutral-400 font-normal block pt-3 ">{t("TOTAL_NUMBER_OF_PLAYERS")}</span>
          </h3>
          <span className="text-4xl ml-auto sm:mr-0  mt-2 sm:mt-0 absolute right-[-10px] top-[-30px] p-3 border z-10 bg-white">
            {/* <img src={earning} className="h-8 w-8 bg-black" alt="earningImg" /> */}
            <GiBabyfootPlayers />

          </span>
        </div>
        {/* <div className="text-center relative  sm:text-left px-3 md:px-4 xl:px-6 lg:px-5 rounded-lg py-4 md:py-8 border">
          <h3 className="text-center mb-0 text-slate-900 font-bold md:text-3xl sm:text-lg dark:text-white">
            <OCountUp value={helpers.formattedAmount(dashboardDetails?.totalActiveOrders)} />
            <span className="text-base text-neutral-400 font-normal block pt-3 ">{t("TOTAL_NUMBERS_OF_ACTIVE_ORDERS")}</span>
          </h3>
          <span className="text-4xl ml-auto sm:mr-0  mt-2 sm:mt-0 absolute right-[-10px] top-[-30px] p-3 border z-10 bg-white">
            <img src={earning} className="h-8 w-8 bg-black" alt="earningImg" />
          </span>
        </div> */}
        {/* <div className="text-center relative  sm:text-left px-3 md:px-4 xl:px-6 lg:px-5 rounded-lg py-4 md:py-8 border">
          <h3 className="text-center mb-0 text-slate-900 font-bold md:text-3xl sm:text-lg dark:text-white">
            <OCountUp value={helpers.formattedAmount(dashboardDetails?.totalOrderPlaced)} />
            <span className="text-base text-neutral-400 font-normal block pt-3 ">{t("TOTAL_NUMBERS_OF_ORDER_PLACED")}</span>
          </h3>
          <span className="text-4xl ml-auto sm:mr-0  mt-2 sm:mt-0 absolute right-[-10px] top-[-30px] p-3 border z-10 bg-white">
            <img src={earning} className="h-8 w-8 bg-black" alt="earningImg" />
          </span>
        </div> */}
      </div>
    </div>
    <div className="dark:bg-gray-800 py-7 px-4 md:px-8 bg-[#F9F9F9] border-solid border-2 border-gray m-10 rounded-md">
      {/* <div className="sm:flex items-center text-center sm:text-left px-3 md:px-4 xl:px-7 lg:px-5  py-4 md:py-8 border dark:bg-slate-900">
        <StyledEngineProvider>
          <ThemeProvider theme={theme}>
            <div className="px-11">
              {generateButton("day", "Daily", selectedButton, handleButtonChange, dateDisableState.first.day, "first")}
              {generateButton("week", "Weekly", selectedButton, handleButtonChange, dateDisableState.first.week, "first")}
              {generateButton("month", "Monthly", selectedButton, handleButtonChange, dateDisableState.first.month, "first")}
              {generateButton("year", "Yearly", selectedButton, handleButtonChange, dateDisableState.first.year, "first")}
            </div>
          </ThemeProvider>
        </StyledEngineProvider>
        <ODateRangePicker
          handleDateChange={(start, end) => handleDateChange(start, end, "first")}
          isReset={isReset}
          setIsReset={setIsReset}
          filterData={{
            endDate: new Date(endDate),
            startDate: new Date(startDate),
          }}
          place="dashboard"
        />
        <button
          type="button"
          onClick={handleReset}
          className="bg-gradientTo text-sm px-8 mb-3 ml-3 py-2 rounded-lg items-center border border-transparent text-white hover:bg-DarkBlue sm:w-auto w-1/2"
        >
          {t("O_RESET")}
        </button>
      </div>
      <div className="sale_report grid grid-cols-1 gap-5 mb-7 bg-white p-4 dark:bg-gray-900 dark:border">
        <div className="flex justify-between"></div>
        <Chart
          options={chartData.options}
          series={chartData.series}
          type="bar"
          // width='1000'
          height="600"
        />
      </div> */}
    </div>
  </>
  )
}

export default Home
