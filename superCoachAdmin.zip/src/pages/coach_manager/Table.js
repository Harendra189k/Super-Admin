
import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import Sidebar from "../../components/sidebar/Sidebar";
import ODateRangePicker from "../../components/shared/datePicker/ODateRangePicker";
import TopNavBar from "../../components/TopNavBar";
import PageSizeList from "../../components/PageSizeList";
import axios from "axios";
import {  RiEdit2Fill } from "react-icons/ri";
import UpdateCoach from "./UpdateCoach";
import { apiGet, apiPut } from '../../services/httpServices';
import { MdDelete } from "react-icons/md";
import DeleteCoach from "./DeleteCoach";
import { pathObj } from "../../services/apiPath";
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import CoachPagination from "./CoachPagination";




const Table = () => {
  const { t } = useTranslation();

  const [coachList, setCoachList] = useState([]);
  const [modelShow, setModelShow] = useState(false)
  const [showDeleteModel, setShowDeleteModel] = useState(false)
  const [fatchData, setFatchData] = useState(false)
  const [show, setShow] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(5);

  const handleClose = () => setShow(false);


  const modelview =(fatchData) => {
    setModelShow(!modelShow)
    setFatchData(fatchData)
    console.log("sgfsdh",fatchData)
  }

  const deleteModelView = (fatchData) => {
    setShowDeleteModel(!showDeleteModel)
    setFatchData(fatchData)
  }

  const handleShow =(fatchData) => {
    setShow(true)
    setFatchData(fatchData)
    console.log("Fatch Data !! ====>>",fatchData)
  }




  // useEffect(() => {

  //   axios
  //     .get("http://localhost:5000/api/prime/getcoach")
  //     .then(function (response) {
  //       // console.log("Response ========>>>", response.data);
  //       setCoachList(response.data);
  //     })
  //     .catch(function (error) {
  //       console.log(error);
  //     });
  // }, [fatchData]);

  const coachData = async (data) => {
    try {
      const response = await apiGet(pathObj.COACH);
      console.log(response, "response===");
  
      if (response.status === 200) {
        setCoachList(response.data);
        setRecords(response.data);
      } else {
        console.log('Something went wrong');
      }
  
    } catch (error) {
      console.error(error);
    }
  };
  useEffect(() => {
    coachData();
  }, [fatchData]);


  const updateStatus = async (id, status) => {
    const payloadData = {
      _id:id,
      status: status};
    try {
      const response = await apiPut(pathObj.UPDATE_STATUS, payloadData);
      if (response.data?.status === 200) {
        coachData()
        handleClose()
      } else {
        console.log("Something went wrong");
      }
    } catch (error) {
      console.error(error);
    }
  };

  const [records, setRecords] = useState([])
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = records.slice(indexOfFirstItem, indexOfLastItem);

  const Filter = (searchText) => {
    if(searchText===""){
       setRecords(currentItems)
    }
    setRecords(
      coachList.filter((coach) =>
      coach.firstName.toLowerCase().includes(searchText.toLowerCase().trim()) ||
      coach.lastName.toLowerCase().includes(searchText.toLowerCase().trim()) ||
      coach.email.toLowerCase().includes(searchText.toLowerCase().trim()) ||
      coach.phone.toString().includes(searchText) 
      )
    );
  };

  return (
    <>
      <div className="">
        <Sidebar />
        <TopNavBar />
        <ODateRangePicker onFilter={Filter} />
        <div className="coach-table overflow-x-auto relative rounded-lg border">
          
          <table className="w-full text-xs text-left text-[#A5A5A5] dark:text-gray-400">
            <thead className="text-xs text-gray-900 border border-[#E1E6EE] bg-[#E1E6EE] dark:bg-gray-700 dark:text-gray-400 dark:border-[#ffffff38]">
              <tr>
                <th scope="col" className="py-3 px-3">
                  {t("S.NO")}
                </th>
                <th scope="col" className="py-3 px-3">
                  {t("FIRST_NAME")}
                </th>
                <th scope="col" className="py-3 px-6">
                  {t("LAST_NAME")}
                </th>
                <th scope="col" className="py-3 px-6">
                  <div className="text-left">{t("O_EMAIL_ID")}</div>
                </th>
                <th scope="col" className="py-3 px-6">
                  <div className="text-left">{t("O_MOBILE_NUMBER")}</div>
                </th>

                <>
                  <th
                    className="py-3 px-6 cursor-pointer text-right"
                    scope="col"
                  >
                    <div className="flex justify-start">
                      <span>{t("JOIN_DATE")} </span>
                      <span></span>
                    </div>
                  </th>
                </>
                <th scope="col" className="py-3 px-6 text-left">
                  {t("O_STATUS")}
                </th>
                <th scope="col" className="py-3 px-6 text-left">
                  {t("O_ACTION")}
                </th>
              </tr>
            </thead>
            <tbody>
              {currentItems.map((coach, index) => (
                <tr key={index}>
                  <td className="border py-3 px-3">{indexOfFirstItem + index + 1}</td>
                  <td className="border py-3 px-3">{coach.firstName}</td>
                  <td className="border py-3 px-3">{coach.lastName}</td>
                  <td className="border py-3 px-3">{coach.email}</td>
                  <td className="border py-3 px-3" style={{ color: 'dark' }}>{coach.phone}</td>
                  <td className="border py-3 px-3">{coach.createdAt}</td>
                  <td className="border py-3 px-3">
                  <label className="switch">
  <input type="checkbox" checked={coach.status==="active" ? true : false} onClick={() =>handleShow(coach)}/>
  <span className="slider round"></span>
</label>
                  </td>
                  
                  <td className="border py-4 px-3 flex">
                  <RiEdit2Fill onClick={()=>modelview(coach)} className="edit-icon" />
                  <MdDelete onClick={() =>deleteModelView(coach)} className="delete-icon"/>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          
        </div>
        <CoachPagination totalItems={coachList.length}
            itemsPerPage={itemsPerPage}
            currentPage={currentPage}
            onPageChange={(pageNumber) => setCurrentPage(pageNumber)}
            onItemsPerPageChange={(pageSize) => setItemsPerPage(pageSize)} />
      </div>

      <Modal show={show} onHide={handleClose} className="status-model">
        <Modal.Header closeButton>
        <Modal.Title>Update Status</Modal.Title>
        </Modal.Header>
        <Modal.Body>Are You Sure to Update Status?</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={() =>updateStatus(fatchData._id,fatchData.status==="active" ? "deactive" : "active")}>
            Update Status
          </Button>
        </Modal.Footer>
      </Modal>
      {modelShow && <UpdateCoach show={modelShow} handleClose={modelview} dataView={fatchData} />}
      {showDeleteModel && <DeleteCoach showdel={showDeleteModel} deleteModelView={deleteModelView} dataView={fatchData}/>}
    </>
  );
};

export default Table;
