  {/* {andOperator(checkSidebarPermission("user_manager"), generateNavLink("/users", "USER_MANAGER", <img src={userManager} className="max-w-[18px]" title={t("USER_MANAGER")} alt="" />))} */}
        {/* {andOperator(
          checkSidebarPermission("subAdmin_manager"),
          generateNavLink("/sub-admin-manager", "SUB_ADMIN_MANAGERS", <img src={SubAdmin} className="max-w-[18px]" title={t("SUB_ADMIN_MANAGERS")} alt="" />)
        )}
        {andOperator(checkSidebarPermission("settings"), generateNavLink("/setting", "SETTINGS", <img src={globalSettings} className="max-w-[18px]" title={t("SETTINGS")} alt="" />))}
        {andOperator(
          checkSidebarPermission("learning_manager"),
          generateNavLink("/learning-manager", "LEARNING_CONTENT_MANAGER", <img src={emailManager} className="max-w-[18px]" title={t("LEARNING_CONTENT_MANAGER")} alt="" />)
        )}
    
        {andOperator(
          checkSidebarPermission("static_page_management"),
          generateNavLink("/static-content", "NAV_STATIC_CONTENTS", <img src={manageStaticContents} className="max-w-[18px]" title={t("NAV_STATIC_CONTENTS")} alt="" />)
        )}
      
        {andOperator( 
          checkSidebarPermission("Investment_Question_Manager"),
          generateNavLink("/investment-question", "INVESTMENT_QUESTION_MANAGER", <img src={manageStaticContents} className="max-w-[18px]" title={t("INVESTMENT_QUESTION_MANAGER")} alt="" />)
        )}  */}

        {/* <Link onClick={handleLogout} className="flex items-center px-4 lg:px-7 py-4 hover:bg-sideBarNavActiveColor hover:text-gradientTo">
          <span className="mr-2">
            <img src={Logout} className="max-w-[18px]" title={t("NAV_LOGOUT")} alt="logout" />
          </span>
          {t("NAV_LOGOUT")}
        </Link> */}